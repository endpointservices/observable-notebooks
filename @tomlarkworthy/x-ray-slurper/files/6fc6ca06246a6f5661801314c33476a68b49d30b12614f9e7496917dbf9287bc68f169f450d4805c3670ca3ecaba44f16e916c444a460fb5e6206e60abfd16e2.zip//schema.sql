


CREATE TABLE weather("location" VARCHAR, date DATE, precipitation DOUBLE, temp_max DOUBLE, temp_min DOUBLE, wind DOUBLE, weather VARCHAR);
CREATE TABLE aapl("Date" DATE, "Open" DOUBLE, "High" DOUBLE, "Low" DOUBLE, "Close" DOUBLE, "Adj Close" DOUBLE, "Volume" DOUBLE);
CREATE TABLE penguins(species VARCHAR, island VARCHAR, culmen_length_mm DOUBLE, culmen_depth_mm DOUBLE, flipper_length_mm DOUBLE, body_mass_g DOUBLE, sex VARCHAR);




