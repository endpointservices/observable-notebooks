COPY weather FROM '/weather.parquet' (FORMAT 'parquet');
COPY aapl FROM '/aapl.parquet' (FORMAT 'parquet');
COPY penguins FROM '/penguins.parquet' (FORMAT 'parquet');
